/*Display all the orders along with product name ordered by a customer having Customer_Id=2 */
 
 select cus_name,pro_name,ord_id,ord_date
 from product as p, supplier_pricing as sp, `order` as o, customer as c
 where
 c.cus_id=2 and 
 c.CUS_ID=o.CUS_ID and
 p.PRO_ID=sp.PRO_ID and 
 o.PRICING_ID=sp.PRICING_ID;
 