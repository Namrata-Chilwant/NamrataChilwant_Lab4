/*Display the Supplier details who can supply more than one product.*/

select sup.supp_id, supp_name, supp_city, supp_phone from supplier as sup
inner join
(select * from supplier_pricing group by SUPP_ID having count(SUPP_ID)>1) as sp 
on sup.supp_id=sp.supp_id;

