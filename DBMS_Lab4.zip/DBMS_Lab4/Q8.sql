/* 8)	Display customer name and gender whose names start or end with character 'A'.*/

SELECT CUS_NAME,CUS_GENDER FROM CUSTOMER 
where CUS_NAME like '%A' OR CUS_NAME like 'A%';