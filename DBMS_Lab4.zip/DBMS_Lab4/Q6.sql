/*Find the least expensive product from each category and print the table with 
category id, name, product name and price of the product*/

select p.CAT_ID,  g.cat_name , p.pro_name, t.price from
(select pro_id,min(supp_price) as price from supplier_pricing group by pro_id) 
as t
inner join product p
on p.pro_id=t.pro_id
inner join category g
on g.cat_id=p.cat_id
group by p.CAT_ID 
order by p.CAT_ID;

 



